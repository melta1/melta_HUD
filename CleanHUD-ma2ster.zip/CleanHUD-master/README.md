# CleanHUD
# Hello!
Hello, this is my first HUD I have made for Garry's Mod and DarkRP. The reason this was made because I like clean, neat and simple script and visuals on a DarkRP server, as you can see this is clean matches any map, and not a busy background it actually has a transparent one!

# Feature List:
DarkRP compatible.
Hassel-free install!
Includes Armor and Health.
Includes money, salary, and current job.
Clean and organized.

# How to install:
Just Drag and drop it in your addons folder, no need to do anything else.

# About issues & contacting me:
Feel free to open a issue anytime I will reply ASAP But for faster response add me on steam as I'm mostly always on :3
Steam: http://steamcommunity.com/id/Lonelywolf1/
